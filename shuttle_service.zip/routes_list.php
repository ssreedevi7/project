<?php
session_start();
$db_host="localhost";
$db_user="root";
$db_password="";
$db_name="shuttle_service";
$db_port="3306";
$result=array();
$conn = mysqli_connect($db_host, $db_user, $db_password, $db_name, $db_port);
?>
<!DOCTYPE>
<html>
<head>
  <title></title>
<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style type="text/css">
  .content {
        width: 75%;
    height: auto;
    position: absolute;
    top: 30%;
    left: 13%;
  }
  .row{
    margin-left: 30px;
  }
  .container{
    width: 800px;
    height: auto;
    position: relative;
    top: 80px;
  }
  .input-txt{
    padding : 20px;
    width: 100%;
  }
</style>
</head>
<body>
<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      
      <a class="navbar-brand" href="#">
      Shuttle Service
        <!-- <img alt="Brand" src="..."> -->
      </a>
    </div>
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="#"><?php echo $_SESSION['name'];?></a></li>
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Services <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="create_busses.php">Create Busses</a></li>
            <li><a href="create_routes.php">Create Routes</a></li>
            <li><a href="bus_list.php">Busses List</a></li>
            <li><a href="">Routes List</a></li>
          </ul>
        </li>
        <li><a href="logout.php">Logout</a></li>
      </ul>
    </div>
  </div>
</nav>
<div class="container">
    <h1>Routes List</h1>
    <form>
          <table class="table table-bordered">
            <thead>
              <th>S.No</th>
              <th>From</th>
              <th>To</th>
              <th>Action</th>
            </thead>
            <tbody><?php
            $query="SELECT id,from_route,to_route FROM routes";
            $rs=mysqli_query($conn, $query) or die("error occurred");
            if(mysqli_num_rows($rs)> 0){
              while ($row = mysqli_fetch_assoc($rs)) {
                            $rows[] = $row;
                        }
            }

            if(isset($rows) && count($rows)>0){
              for($i=0;$i<count($rows);$i++){
              ?>
              <tr>
                <td><?php echo $i+1; ?></td>
                <td><?php echo $rows[$i]["from_route"];?></td>
                <td><?php echo $rows[$i]["to_route"];?></td>
                <td><a href="#" onclick="deleteRoute(<?php echo "'".$rows[$i]["id"]."'"?>);">delete</a></td>
              </tr>
              <?php }}
            ?>
            </tbody>
          </table>
  </form>
</div>
<script type="text/javascript">
      function deleteRoute(routeId){
        var id=routeId;
        $.post("php/delete_route.php",
        {
            id: routeId
        },
        function(data){
          var result=$.parseJSON(data);
          if(result.status=="success"){
            alert(result.message);
            location.reload();
          }
          else{
            alert(result.message);
          }
        });
      }
    </script>
</body>
</html>