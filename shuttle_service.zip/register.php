<?php

$db_host="localhost";
$db_user="root";
$db_password="";
$db_name="shuttle_service";
$db_port="3306";
$response=$rows=$result=array();
$conn = mysqli_connect($db_host, $db_user, $db_password, $db_name, $db_port);

$userid=isset($_POST["user_id"]) ? $_POST["user_id"] : "";
$password=isset($_POST["password"]) ? $_POST["password"] : "";
$name=isset($_POST["name"]) ? $_POST["name"] : "";
$phone=isset($_POST["phone"]) ? $_POST["phone"] : "";
$email=isset($_POST["email"]) ? $_POST["email"] : "";

$query="select * from signin where userid='".$userid."'";
$rs=mysqli_query($conn, $query) or die("error occurred");
if(mysqli_num_rows($rs)> 0){
	while ($row = mysqli_fetch_assoc($rs)) {
                $rows[] = $row;
            }
}

if(count($rows)>0){
	$response["status"]="failed";	
	$response["message"]="Account is already Exists with this UserId";	
}
else{
	$query="INSERT INTO signin (userid,password,name,phone,email,type) values ('$userid','$password','$name','$phone','$email','0')";
		$result=mysqli_query($conn, $query) or die("error occurred while inserting");
		if($result){
		$response["status"]="success";
		$response["message"]="Account Created Successfully"	;
		}
		else{
			$response["status"]="failed"	;
			$response["message"]="Unable to Create Account"	;
		}
}
echo json_encode($response);
?>