<?php
session_start();
$db_host="localhost";
$db_user="root";
$db_password="";
$db_name="shuttle_service";
$db_port="3306";
$rows=$result=array();
$conn = mysqli_connect($db_host, $db_user, $db_password, $db_name, $db_port);
?>
<!DOCTYPE>
<html>
<head>
  <title></title>
<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style type="text/css">
  .content {
        width: 75%;
    height: auto;
    position: absolute;
    top: 30%;
    left: 13%;
  }
  .row{
    margin-left: 30px;
  }
  .container{
    width: 500px;
    height: auto;
    position: relative;
    top: 50px;
  }
  .input-txt{
    padding : 20px;
    width: 100%;
  }
  .container2{
    width: 800px;
    height: auto;
    position: relative;
    top: 10px;
    left : 300px;
  }

</style>
</head>
<body>
<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      
      <a class="navbar-brand" href="#">
      Shuttle Service
        <!-- <img alt="Brand" src="..."> -->
      </a>
    </div>
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="#"><?php echo isset($_SESSION["name"]) ? $_SESSION["name"] : "";?></a></li>
        <li><a href="logout.php">Logout</a></li>
      </ul>
    </div>
  </div>
</nav>
    <div class="container">
    <h1 style="text-align: center">Book Bus</h1>
          </br>
          </br>
  <form action="#" method="POST">
          <select name="from" id="from" class="input-txt" onchange="to_list();">
            <option value="">Select Pickup Location</option>
            <?php
            $query="SELECT distinct from_route FROM routes";
            $rs=mysqli_query($conn, $query) or die("error occurred");
            if(mysqli_num_rows($rs)> 0){
              while ($row = mysqli_fetch_assoc($rs)) {
                            $rows[] = $row;
                        }
            }

            if(isset($rows) && count($rows)>0){
              for($i=0;$i<count($rows);$i++){
              ?>
              <option value="<?php echo $rows[$i]['from_route'];?>"><?php echo $rows[$i]['from_route'];?></option>
              <?php }}
            ?>
          </select>
          </br>
          </br>
          </br>
          <select name="to" id="to" class="input-txt">
            <option>Select Drop Location</option>
          </select>
          </br>
          </br>
          </br>
          <center><button onclick="bookbus();" class="btn btn-success"> Book</button></center>
  </form>
    </div>

<div class="container2">
    <h1>History</h1>
    <form>
          <table class="table table-bordered">
            <thead>
              <th>S.No</th>
              <th>Bus Number</th>
              <th>Driver Name</th>
              <th>Driver Phone Number</th>
              <th>Route</th>
              <th>Reserved Date</th>
              <th>Booking Status</th>
              <th>Action</th>
            </thead>
            <tbody>
            <?php
            $rows=array();
            $query="SELECT distinct t.id,r.from_route,r.to_route,t.date,t.status,bd.bus_number,bd.driver_name,bd.driver_phone FROM transactions t,bus_details bd,routes r where bd.route_id=r.id and t.bus_id=bd.id and t.user_id='".$_SESSION['userid']."'";
            $rs=mysqli_query($conn, $query) or die("error occurred");
            if(mysqli_num_rows($rs)> 0){
              while ($row = mysqli_fetch_assoc($rs)) {
                            $rows[] = $row;
                        }
            }

            if(isset($rows) && count($rows)>0){
              for($i=0;$i<count($rows);$i++){
              ?>
              <tr>
                <td><?php echo $i+1; ?></td>
                <td><?php echo $rows[$i]["bus_number"];?></td>
                <td><?php echo $rows[$i]["driver_name"];?></td>
                <td><?php echo $rows[$i]["driver_phone"];?></td>
                <td><?php echo $rows[$i]["from_route"]."<b> --- </b>".$rows[$i]["to_route"];?></td>
                <td><?php echo $rows[$i]["date"];?></td>
                <td><?php echo $rows[$i]["status"];?></td>
                <td><?php echo $rows[$i]["status"] !="reserved" ? "N/A" : "<a href='#' onclick=cancelSeat('".$rows[$i]["id"]."');>Cancel</a>";?>
              </tr>
            <?php }}
            ?>
            </tbody>
          </table>
  </form>
</div>
    <script type="text/javascript">
      function bookbus(){
        var from_data=$("#from").val();
        var to_data=$("#to").val();
        if(from_data=="" || to_data==""){
          alert("");
          return;
        }

        $.post("php/book_bus.php",
        {
            from_route: from_data,
            to_route : to_data
        },
        function(data){
          var result=$.parseJSON(data);
          if(result.status=="success"){
            alert(result.message);
            location.reload();
          }
          else{
            alert(result.message);
          }
        });
      }
      function to_list(){
        var from_data=$("#from").val();
        if(from_data==""){
          alert("");
          $('#to').find('option:not(:first)').remove();
          return;
        }
        $.post("php/to_list.php",
        {
            from_route: from_data
        },
        function(data){
            var result=$.parseJSON(data);
            if(result.status=="success"){
              $('#to').find('option:not(:first)').remove();
              for(var i=0;i<result.data.length;i++){
                $('#to').append('<option value="'+result.data[i].to_route+'">'+result.data[i].to_route+'</option>');
              }
            }
          else{
            alert(result.status);
          }
        });
      }
      function cancelSeat(transactionId){
        var id=transactionId;
        $.post("php/cancel_seat.php",
        {
            id: id
        },
        function(data){
            var result=$.parseJSON(data);
            if(result.status=="success"){
              alert(result.message);
              location.reload();
            }
          else{
            alert(result.message);
          }
        });
      }
    </script>
</body>
</html>