<?php
session_start();
$db_host="localhost";
$db_user="root";
$db_password="";
$db_name="shuttle_service";
$db_port="3306";
$result=array();
$conn = mysqli_connect($db_host, $db_user, $db_password, $db_name, $db_port);

$from_route=isset($_POST["from_route"]) ? $_POST["from_route"] : "";

$query="SELECT distinct to_route FROM routes WHERE from_route='".$from_route."'";

$rs=mysqli_query($conn, $query) or die("error occurred");
if(mysqli_num_rows($rs)> 0){
	while ($row = mysqli_fetch_assoc($rs)) {
                $rows[] = $row;
            }
}

if(count($rows)>0){
	$result["status"]="success";
	$result["data"]=$rows;
}
else{
	$result["status"]="No data Found";	
}
echo json_encode($result);
?>