<?php
session_start();
$db_host="localhost";
$db_user="root";
$db_password="";
$db_name="shuttle_service";
$db_port="3306";
$rows=$result=$response=array();
$conn = mysqli_connect($db_host, $db_user, $db_password, $db_name, $db_port);

$to_area=$_POST["to_area"];
$from_area=$_POST["from_area"];

$query="select * from routes where from_route='".$from_area."' and  to_route='".$to_area."'";
$rs=mysqli_query($conn, $query) or die("error occurred");
if(mysqli_num_rows($rs)> 0){
	while ($row = mysqli_fetch_assoc($rs)) {
                $rows[] = $row;
            }
}


if(count($rows)>0){
		$response["status"]="failed";
		$response["message"]="Route Is already exists with the given details";
	}
	else{
	$query="INSERT INTO routes (from_route,to_route) values ('$from_area','$to_area')";
		$result=mysqli_query($conn, $query) or die("error occurred while inserting");
		if($result){
		$response["status"]="success"	;
		$response["message"]="Route Created Successfully"	;
		}
		else{
			$response["status"]="failed"	;
			$response["message"]="Unable to Create Route"	;
		}
	}

echo json_encode($response);
?>