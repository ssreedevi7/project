<?php
session_start();
$db_host="localhost";
$db_user="root";
$db_password="";
$db_name="shuttle_service";
$db_port="3306";
$rows=$result=$response=array();
$conn = mysqli_connect($db_host, $db_user, $db_password, $db_name, $db_port);

$bus_number=$_POST["bus_number"];
$driver_name=$_POST["driver_name"];
$driver_phone=$_POST["driver_phone"];
$route_id=$_POST["route_id"];

$query="select * from bus_details where bus_number='".$bus_number."'";
$rs=mysqli_query($conn, $query) or die("error occurred");
if(mysqli_num_rows($rs)> 0){
	while ($row = mysqli_fetch_assoc($rs)) {
                $rows[] = $row;
            }
}


if(count($rows)>0){
		$response["status"]="failed";
		$response["message"]="Bus Has Already Exists with this Number";
	}
	else{
	$query="INSERT INTO bus_details (bus_number,driver_name,driver_phone,route_id) values ('$bus_number','$driver_name','$driver_phone','$route_id')";
		$result=mysqli_query($conn, $query) or die("error occurred while inserting");
		if($result){
		$response["status"]="success"	;
		$response["message"]="Bus Created Successfully"	;
		}
		else{
			$response["status"]="failed"	;
			$response["message"]="Unable to Create Bus"	;
		}
	}

echo json_encode($response);
?>