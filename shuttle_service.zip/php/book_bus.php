<?php
session_start();
$db_host="localhost";
$db_user="root";
$db_password="";
$db_name="shuttle_service";
$db_port="3306";
$rows=$result=$response=array();
$conn = mysqli_connect($db_host, $db_user, $db_password, $db_name, $db_port);

$from=$_POST["from_route"];
$to=$_POST["to_route"];

$query="select distinct bus.id from bus_details bus,routes r where r.id=bus.route_id and from_route='".$from."' and to_route='".$to."'";
$rs=mysqli_query($conn, $query) or die("error occurred");
if(mysqli_num_rows($rs)> 0){
	while ($row = mysqli_fetch_assoc($rs)) {
                $rows[] = $row;
            }
}


if(count($rows)>0){
	$query="INSERT INTO transactions (bus_id,user_id,status) values ('".$rows[0]['id']."','".$_SESSION['userid']."','reserved')";
		$result=mysqli_query($conn, $query) or die("error occurred while inserting");
		if($result){
		$response["status"]="success"	;
		$response["message"]="Your Seat has Been Reserved"	;
		}
		else{
			$response["status"]="failed"	;
			$response["message"]="Unable to Reserve Seat"	;
		}
	}
	else{
		$response["status"]="failed";
		$response["message"]="No Bus Details Found Please Try Another Option !!";
	}

echo json_encode($response);
?>