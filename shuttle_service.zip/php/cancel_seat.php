<?php
session_start();
$db_host="localhost";
$db_user="root";
$db_password="";
$db_name="shuttle_service";
$db_port="3306";
$rows=$result=$response=array();
$conn = mysqli_connect($db_host, $db_user, $db_password, $db_name, $db_port);

$id=$_POST["id"];

$query="select * from transactions where id='".$id."'";
$rs=mysqli_query($conn, $query) or die("error occurred");
if(mysqli_num_rows($rs)> 0){
	while ($row = mysqli_fetch_assoc($rs)) {
                $rows[] = $row;
            }
}


if(count($rows)>0){
	$query="UPDATE transactions set status='cancelled' where id='$id' and user_id='".$_SESSION['userid']."'";
		$result=mysqli_query($conn, $query) or die("error occurred while inserting");
		if($result){
		$response["status"]="success"	;
		$response["message"]="Your Seat has Been Cancelled"	;
		}
		else{
			$response["status"]="failed"	;
			$response["message"]="Unable to cancel the Seat"	;
		}
	}
	else{
		$response["status"]="failed";
		$response["message"]="No Seat has Reserved with selected details !!";
	}

echo json_encode($response);
?>