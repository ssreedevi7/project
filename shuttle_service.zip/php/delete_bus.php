<?php
session_start();
$db_host="localhost";
$db_user="root";
$db_password="";
$db_name="shuttle_service";
$db_port="3306";
$rows=$result=$response=array();
$conn = mysqli_connect($db_host, $db_user, $db_password, $db_name, $db_port);

$id=$_POST["id"];

$query="select * from bus_details where id='".$id."'";
$rs=mysqli_query($conn, $query) or die("error occurred");
if(mysqli_num_rows($rs)> 0){
	while ($row = mysqli_fetch_assoc($rs)) {
                $rows[] = $row;
            }
}


if(count($rows)>0){
	$query="delete from bus_details where id='$id'";
		$result=mysqli_query($conn, $query) or die("error occurred while deleting");
		if($result){
		$response["status"]="success"	;
		$response["message"]="Bus Has Been Deleted"	;
		}
		else{
			$response["status"]="failed"	;
			$response["message"]="Unable to delete the Bus"	;
		}
	}
	else{
		$response["status"]="failed";
		$response["message"]="No Bus Found with selected details !!";
	}

echo json_encode($response);
?>