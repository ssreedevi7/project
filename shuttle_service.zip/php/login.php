<?php
$db_host="localhost";
$db_user="root";
$db_password="";
$db_name="shuttle_service";
$db_port="3306";
$result=array();
$conn = mysqli_connect($db_host, $db_user, $db_password, $db_name, $db_port);

$userid=isset($_POST["userid"]) ? $_POST["userid"] : "";
$password=isset($_POST["password"]) ? $_POST["password"] : "";

$query="select * from signin where userid='".$user_name."' and password='".$password."'";
$rs=mysqli_query($conn, $query) or die("error occurred");
if(mysqli_num_rows($rs)> 0){
	while ($row = mysqli_fetch_assoc($rs)) {
                $rows[] = $row;
            }
}

if(count($rows)>0){
	$result["status"]="success";
	$result["type"]=$rows[0]["login_type"];
	$_SESSION["phone"]=$rows[0]["phone"];
	$_SESSION["userid"]=$rows[0]["userid"];
	$_SESSION["name"]=$rows[0]["name"];
	$_SESSION["email"]=$rows[0]["email"];
	$_SESSION["type"]=$rows[0]["type"];
}
else{
	$result["status"]="Username or Password Does not exists";	
}
echo json_encode($result);
?>